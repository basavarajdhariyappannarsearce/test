import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import dotenv from 'dotenv';
import salesData from '../../sales.json';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(helmet());
app.use(cors());
app.use(express.json());

// Types
interface SalesRecord {
  "Row ID": number;
  "Order ID": string;
  "Order Date": string;
  "Ship Date": string;
  "Ship Mode": string;
  "Customer ID": string;
  "Customer Name": string;
  Segment: string;
  Country: string;
  City: string;
  State: string;
  "Postal Code": string;
  Region: string;
  "Product ID": string;
  Category: string;
  "Sub-Category": string;
  "Product Name": string;
  Sales: number;
  Quantity: number;
  Discount: number;
  Profit: number;
}

// API Routes

// Get list of states
app.get('/api/states', (req, res) => {
  try {
    const states = [...new Set((salesData as SalesRecord[]).map(record => record.State))];
    const sortedStates = states.filter(state => state && state.trim() !== '').sort();
    res.json(sortedStates);
  } catch (error) {
    console.error('Error fetching states:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get date bounds for a state
app.get('/api/date-bounds', (req, res) => {
  try {
    const { state } = req.query;
    
    if (!state) {
      return res.status(400).json({ error: 'State parameter is required' });
    }

    const stateData = (salesData as SalesRecord[]).filter(record => record.State === state);
    
    if (stateData.length === 0) {
      return res.status(404).json({ error: 'No data found for the specified state' });
    }

    const dates = stateData.map(record => new Date(record['Order Date']));
    const minDate = new Date(Math.min(...dates.map(d => d.getTime())));
    const maxDate = new Date(Math.max(...dates.map(d => d.getTime())));

    res.json({
      minDate: minDate.toISOString().split('T')[0],
      maxDate: maxDate.toISOString().split('T')[0]
    });
  } catch (error) {
    console.error('Error fetching date bounds:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get dashboard data
app.get('/api/dashboard-data', (req, res) => {
  try {
    const { state, fromDate, toDate, customerId } = req.query;
    
    if (!state || !fromDate || !toDate) {
      return res.status(400).json({ 
        error: 'State, fromDate, and toDate parameters are required' 
      });
    }

    let filteredData = (salesData as SalesRecord[]).filter(record => {
      const recordDate = new Date(record['Order Date']);
      const from = new Date(fromDate as string);
      const to = new Date(toDate as string);
      
      return record.State === state && 
             recordDate >= from && 
             recordDate <= to &&
             (!customerId || record['Customer ID'] === customerId);
    });

    if (filteredData.length === 0) {
      return res.status(404).json({ error: 'No data found for the specified criteria' });
    }

    // Calculate metrics
    const totalSales = filteredData.reduce((sum, record) => sum + record.Sales, 0);
    const totalProfit = filteredData.reduce((sum, record) => sum + record.Profit, 0);
    const totalOrders = new Set(filteredData.map(record => record['Order ID'])).size;
    const totalCustomers = new Set(filteredData.map(record => record['Customer ID'])).size;

    // Sales by category
    const salesByCategory = filteredData.reduce((acc, record) => {
      const category = record.Category;
      acc[category] = (acc[category] || 0) + record.Sales;
      return acc;
    }, {} as Record<string, number>);

    const salesByCategoryArray = Object.entries(salesByCategory).map(([name, value]) => ({
      name,
      value
    }));

    // Sales by region
    const salesByRegion = filteredData.reduce((acc, record) => {
      const region = record.Region;
      acc[region] = (acc[region] || 0) + record.Sales;
      return acc;
    }, {} as Record<string, number>);

    const salesByRegionArray = Object.entries(salesByRegion).map(([name, value]) => ({
      name,
      value
    }));

    // Monthly sales
    const monthlySales = filteredData.reduce((acc, record) => {
      const date = new Date(record['Order Date']);
      const monthYear = date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
      acc[monthYear] = (acc[monthYear] || 0) + record.Sales;
      return acc;
    }, {} as Record<string, number>);

    const monthlySalesArray = Object.entries(monthlySales)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => new Date(a.name).getTime() - new Date(b.name).getTime());

    res.json({
      totalSales,
      totalProfit,
      totalOrders,
      totalCustomers,
      salesByCategory: salesByCategoryArray,
      salesByRegion: salesByRegionArray,
      monthlySales: monthlySalesArray
    });

  } catch (error) {
    console.error('Error fetching dashboard data:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', timestamp: new Date().toISOString() });
});

// Start server
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
  console.log(`Health check: http://localhost:${PORT}/api/health`);
  console.log(`States API: http://localhost:${PORT}/api/states`);
});
