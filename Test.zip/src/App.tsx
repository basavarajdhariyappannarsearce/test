import React from 'react';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import Dashboard from './components/Dashboard';

const App: React.FC = () => {
  const [mode, setMode] = React.useState<'light' | 'dark'>('light');

  const theme = createTheme({
    palette: {
      mode,
      primary: {
        main: '#0C6470',
      },
      secondary: {
        main: '#4A4A4A',
      },
      background: {
        default: mode === 'light' ? '#DDDDDD' : '#121212',
        paper: mode === 'light' ? '#FFFFFF' : '#1E1E1E',
      },
    },
    typography: {
      fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif',
    },
  });

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Dashboard mode={mode} setMode={setMode} />
    </ThemeProvider>
  );
};

export default App;
