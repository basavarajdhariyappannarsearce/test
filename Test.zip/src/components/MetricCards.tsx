import React from 'react';
import { Grid, Card, CardContent, Typography, Box } from '@mui/material';
import {
  TrendingUp,
  AttachMoney,
  ShoppingCart,
  People,
} from '@mui/icons-material';

interface MetricCardsProps {
  data: {
    totalSales: number;
    totalProfit: number;
    totalOrders: number;
    totalCustomers: number;
  };
}

const MetricCards: React.FC<MetricCardsProps> = ({ data }) => {
  const metrics = [
    {
      title: 'Total Sales',
      value: `$${data.totalSales.toLocaleString()}`,
      icon: <AttachMoney />,
      color: '#2196F3',
      bgColor: '#E3F2FD',
    },
    {
      title: 'Total Profit',
      value: `$${data.totalProfit.toLocaleString()}`,
      icon: <TrendingUp />,
      color: '#4CAF50',
      bgColor: '#E8F5E8',
    },
    {
      title: 'Total Orders',
      value: data.totalOrders.toLocaleString(),
      icon: <ShoppingCart />,
      color: '#9C27B0',
      bgColor: '#F3E5F5',
    },
    {
      title: 'Customers',
      value: data.totalCustomers.toLocaleString(),
      icon: <People />,
      color: '#FF9800',
      bgColor: '#FFF3E0',
    },
  ];

  return (
    <Grid container spacing={3} sx={{ mb: 4 }}>
      {metrics.map((metric, index) => (
        <Grid item xs={12} sm={6} md={3} key={index}>
          <Card sx={{ height: '100%' }}>
            <CardContent>
              <Box display="flex" alignItems="center" justifyContent="space-between">
                <Box>
                  <Typography color="textSecondary" gutterBottom variant="h6">
                    {metric.title}
                  </Typography>
                  <Typography variant="h4" component="h2">
                    {metric.value}
                  </Typography>
                </Box>
                <Box
                  sx={{
                    backgroundColor: metric.bgColor,
                    borderRadius: '50%',
                    p: 2,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Box sx={{ color: metric.color }}>{metric.icon}</Box>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>
      ))}
    </Grid>
  );
};

export default MetricCards;
