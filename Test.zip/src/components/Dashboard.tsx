import React, { useState, useEffect } from 'react';
import {
  Box,
  Drawer,
  AppBar,
  Toolbar,
  Typography,
  IconButton,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Card,
  CardContent,
  Grid,
  Switch,
  FormControlLabel,
  useTheme,
  useMediaQuery,
} from '@mui/material';
import {
  Menu,
  Dashboard as DashboardIcon,
  TrendingUp,
  ShoppingCart,
  People,
  Settings,
  Brightness4,
  Brightness7,
  ChevronLeft,
  ChevronRight,
} from '@mui/icons-material';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import dayjs, { Dayjs } from 'dayjs';
import MetricCards from './MetricCards';
import SalesCharts from './SalesCharts';

const DRAWER_WIDTH = 240;

const menuItems = [
  { text: 'Dashboard', icon: <DashboardIcon /> },
  { text: 'Sales', icon: <TrendingUp /> },
  { text: 'Orders', icon: <ShoppingCart /> },
  { text: 'Customers', icon: <People /> },
  { text: 'Settings', icon: <Settings /> },
];

interface DashboardProps {
  mode: 'light' | 'dark';
  setMode: (mode: 'light' | 'dark') => void;
}

const Dashboard: React.FC<DashboardProps> = ({ mode, setMode }) => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  const [drawerOpen, setDrawerOpen] = useState(!isMobile);
  const [selectedState, setSelectedState] = useState('');
  const [states, setStates] = useState<string[]>([]);
  const [fromDate, setFromDate] = useState<Dayjs | null>(null);
  const [toDate, setToDate] = useState<Dayjs | null>(null);
  const [dashboardData, setDashboardData] = useState<any>(null);

  useEffect(() => {
    // Fetch states from API
    fetchStates();
  }, []);

  useEffect(() => {
    if (selectedState) {
      // Fetch date bounds for selected state
      fetchDateBounds(selectedState);
    }
  }, [selectedState]);

  useEffect(() => {
    if (selectedState && fromDate && toDate) {
      // Fetch dashboard data
      fetchDashboardData(selectedState, fromDate, toDate);
    }
  }, [selectedState, fromDate, toDate]);

  const fetchStates = async () => {
    try {
      const response = await fetch('http://localhost:3001/api/states');
      const data = await response.json();
      setStates(data);
      if (data.length > 0) {
        setSelectedState(data[0]); // Select first state by default
      }
    } catch (error) {
      console.error('Error fetching states:', error);
      // Fallback to mock data
      setStates(['California', 'Texas', 'New York', 'Florida', 'Illinois']);
      setSelectedState('California');
    }
  };

  const fetchDateBounds = async (state: string) => {
    try {
      const response = await fetch(`http://localhost:3001/api/date-bounds?state=${state}`);
      const data = await response.json();
      setFromDate(dayjs(data.minDate));
      setToDate(dayjs(data.maxDate));
    } catch (error) {
      console.error('Error fetching date bounds:', error);
      // Fallback to mock data
      setFromDate(dayjs('2020-01-01'));
      setToDate(dayjs('2023-12-31'));
    }
  };

  const fetchDashboardData = async (state: string, from: Dayjs, to: Dayjs) => {
    try {
      const response = await fetch(
        `http://localhost:3001/api/dashboard-data?state=${state}&fromDate=${from.format('YYYY-MM-DD')}&toDate=${to.format('YYYY-MM-DD')}`
      );
      const data = await response.json();
      setDashboardData(data);
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
      // Fallback to mock data
      setDashboardData({
        totalSales: 1250000,
        totalProfit: 340000,
        totalOrders: 4521,
        totalCustomers: 892,
        salesByCategory: [
          { name: 'Furniture', value: 450000 },
          { name: 'Office Supplies', value: 320000 },
          { name: 'Technology', value: 480000 },
        ],
        salesByRegion: [
          { name: 'East', value: 380000 },
          { name: 'West', value: 420000 },
          { name: 'Central', value: 450000 },
        ],
        monthlySales: [
          { name: 'Jan', value: 95000 },
          { name: 'Feb', value: 102000 },
          { name: 'Mar', value: 118000 },
          { name: 'Apr', value: 125000 },
          { name: 'May', value: 132000 },
          { name: 'Jun', value: 141000 },
        ],
      });
    }
  };

  const handleDrawerToggle = () => {
    setDrawerOpen(!drawerOpen);
  };

  return (
    <Box sx={{ display: 'flex' }}>
      <AppBar
        position="fixed"
        sx={{
          width: { md: `calc(100% - ${drawerOpen ? DRAWER_WIDTH : 0}px)` },
          ml: { md: `${drawerOpen ? DRAWER_WIDTH : 0}px` },
          bgcolor: '#0C6470',
          transition: theme.transitions.create(['width', 'margin'], {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.leavingScreen,
          }),
        }}
      >
        <Toolbar>
          <IconButton
            color="inherit"
            aria-label="open drawer"
            edge="start"
            onClick={handleDrawerToggle}
            sx={{ mr: 2 }}
          >
            {drawerOpen ? <ChevronLeft /> : <Menu />}
          </IconButton>
          <Typography variant="h6" noWrap component="div" sx={{ flexGrow: 1 }}>
            Sales Dashboard
          </Typography>
          <FormControlLabel
            control={
              <Switch
                checked={mode === 'dark'}
                onChange={() => setMode(mode === 'light' ? 'dark' : 'light')}
                color="default"
              />
            }
            label={mode === 'dark' ? <Brightness4 /> : <Brightness7 />}
            labelPlacement="start"
            sx={{ color: 'white' }}
          />
        </Toolbar>
      </AppBar>

      <Drawer
        variant={isMobile ? 'temporary' : 'persistent'}
        anchor="left"
        open={drawerOpen}
        onClose={handleDrawerToggle}
        sx={{
          width: DRAWER_WIDTH,
          flexShrink: 0,
          '& .MuiDrawer-paper': {
            width: DRAWER_WIDTH,
            boxSizing: 'border-box',
            bgcolor: '#4A4A4A',
            color: 'white',
          },
        }}
      >
        <Toolbar />
        <Box sx={{ overflow: 'auto' }}>
          <List>
            {menuItems.map((item) => (
              <ListItem key={item.text} disablePadding>
                <ListItemIcon sx={{ color: 'white' }}>{item.icon}</ListItemIcon>
                <ListItemText primary={item.text} />
              </ListItem>
            ))}
          </List>
        </Box>
      </Drawer>

      <Box
        component="main"
        sx={{
          flexGrow: 1,
          p: 3,
          width: { md: `calc(100% - ${drawerOpen ? DRAWER_WIDTH : 0}px)` },
          bgcolor: theme.palette.background.default,
          minHeight: '100vh',
          transition: theme.transitions.create(['width', 'margin'], {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.leavingScreen,
          }),
        }}
      >
        <Toolbar />
        
        {/* Filters */}
        <Card sx={{ mb: 3 }}>
          <CardContent>
            <Grid container spacing={2} alignItems="center">
              <Grid size={{ xs: 12, sm: 6, md: 3 }}>
                <FormControl fullWidth>
                  <InputLabel>State</InputLabel>
                  <Select
                    value={selectedState}
                    label="State"
                    onChange={(e) => setSelectedState(e.target.value)}
                  >
                    {states.map((state) => (
                      <MenuItem key={state} value={state}>
                        {state}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>
              <Grid size={{ xs: 12, sm: 6, md: 3 }}>
                <LocalizationProvider dateAdapter={AdapterDayjs}>
                  <DatePicker
                    label="From Date"
                    value={fromDate}
                    onChange={(newValue) => setFromDate(newValue)}
                    slotProps={{ textField: { fullWidth: true } }}
                  />
                </LocalizationProvider>
              </Grid>
              <Grid size={{ xs: 12, sm: 6, md: 3 }}>
                <LocalizationProvider dateAdapter={AdapterDayjs}>
                  <DatePicker
                    label="To Date"
                    value={toDate}
                    onChange={(newValue) => setToDate(newValue)}
                    slotProps={{ textField: { fullWidth: true } }}
                  />
                </LocalizationProvider>
              </Grid>
            </Grid>
          </CardContent>
        </Card>

        {/* Dashboard Content */}
        {dashboardData && (
          <>
            <MetricCards data={dashboardData} />
            <SalesCharts data={dashboardData} />
          </>
        )}
      </Box>
    </Box>
  );
};

export default Dashboard;
