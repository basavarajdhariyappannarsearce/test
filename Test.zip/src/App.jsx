import React, { useState, useEffect } from 'react';
import SalesDashboard from './components/SalesDashboard';
import './App.css';

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <SalesDashboard />
    </div>
  );
}

export default App;
